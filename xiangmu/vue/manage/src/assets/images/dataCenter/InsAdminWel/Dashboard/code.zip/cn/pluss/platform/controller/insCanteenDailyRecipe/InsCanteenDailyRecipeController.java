package cn.pluss.platform.controller.InsCanteenDailyRecipe;

import cn.pluss.platform.base.BaseController;
import java.util.Map;
import java.util.List;
import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;
import cn.pluss.platform.util.StringUtil;
import javax.servlet.http.HttpServletRequest;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import cn.pluss.platform.model.entity.InsCanteenDailyRecipe;
import cn.pluss.platform.insCanteenDailyRecipe.InsCanteenDailyRecipeService;

@Controller
@RequestMapping("insCanteenDailyRecipe")
public class InsCanteenDailyRecipeController  extends BaseController{

    private Integer PAGE_SIZE=12;

    @Autowired
    private InsCanteenDailyRecipeService insCanteenDailyRecipeService;

    /**
    *引导页
    * @return
    */
    @RequestMapping(value = "/index", method = RequestMethod.GET)
    public String index(HttpServletRequest request,Integer pageIndex) {
        if(pageIndex==null||pageIndex==0) {
        pageIndex=1;
        }
        request.setAttribute("pageIndex", pageIndex);
        return "insCanteenDailyRecipe/insCanteenDailyRecipeList";
    }

    /**
    *分页查询
    */
    @RequestMapping(value = "/queryInsCanteenDailyRecipeByPage", method = RequestMethod.GET)
    @ResponseBody
    public  Map<String,Object> queryInsCanteenDailyRecipeByPage(Integer page,Integer limit,Integer id) {

        if(page==null) {
        page=1;
        }
        Map<String,Object> map=new HashMap<String, Object>();
        map.put("pageSize",limit);
        map.put("offset",(page-1)*limit);
        map.put("id",  id);
        List<InsCanteenDailyRecipe> insCanteenDailyRecipeList=insCanteenDailyRecipeService.queryPage(map);
        Integer count=insCanteenDailyRecipeService.queryPageCount(map);
        Map<String,Object> reslut=new HashMap<String,Object>();
        reslut.put("code", 0);
        reslut.put("count", count);
        reslut.put("data",insCanteenDailyRecipeList);
        return reslut;
    }
    /**
    *查询详情
    */
    @RequestMapping(value = "/queryInsCanteenDailyRecipeDetails", method = RequestMethod.GET)
    public String queryInsCanteenDailyRecipeDetails(HttpServletRequest request,Integer id,Integer pageIndex){

        if(id!=null&&id!=0) {
        InsCanteenDailyRecipe insCanteenDailyRecipe=new InsCanteenDailyRecipe();
        insCanteenDailyRecipe.setId(id);
        insCanteenDailyRecipe=insCanteenDailyRecipeService.queryInsCanteenDailyRecipe(insCanteenDailyRecipe);
        request.setAttribute("insCanteenDailyRecipe", insCanteenDailyRecipe);
        request.setAttribute("pageIndex", pageIndex);
        }
        return "insCanteenDailyRecipe/insCanteenDailyRecipeDetails";
    }
    /**
    *查询详情
    */
    @RequestMapping(value = "/queryInsCanteenDailyRecipeBaseInfo", method = RequestMethod.GET)
    public String queryInsCanteenDailyRecipeBaseInfo(HttpServletRequest request,Integer id,Integer pageIndex){

        if(id!=null&&id!=0) {
        InsCanteenDailyRecipe insCanteenDailyRecipe=new InsCanteenDailyRecipe();
        insCanteenDailyRecipe.setId(id);
        insCanteenDailyRecipe=insCanteenDailyRecipeService.queryInsCanteenDailyRecipe(insCanteenDailyRecipe);
        request.setAttribute("insCanteenDailyRecipe", insCanteenDailyRecipe);
        request.setAttribute("pageIndex", pageIndex);
        }
        return "insCanteenDailyRecipe/insCanteenDailyRecipeBaseInfo";
    }
    /**
    *查询详情
    */
    @RequestMapping(value = "/queryInsCanteenDailyRecipeExtendsInfo", method = RequestMethod.GET)
    public String queryInsCanteenDailyRecipeExtendsInfo(){

        return "insCanteenDailyRecipe/insCanteenDailyRecipedExtendsInfo";
    }
    /**
    *查询详情
    */
    @RequestMapping(value = "/queryInsCanteenDailyRecipeFunctionsInfo", method = RequestMethod.GET)
    public String queryInsCanteenDailyRecipeFunctionsInfo(){

        return "insCanteenDailyRecipe/insCanteenDailyRecipeFunctionsInfo";
    }
    /**
    *保存对象
    */
    @RequestMapping(value = "/saveInsCanteenDailyRecipe", method = RequestMethod.POST)
    @ResponseBody
    public Map<String,Object> saveInsCanteenDailyRecipe(InsCanteenDailyRecipe insCanteenDailyRecipe){

        if(insCanteenDailyRecipe.getId()!=null&&insCanteenDailyRecipe.getId()!=0){
            insCanteenDailyRecipeService.updateInsCanteenDailyRecipe(insCanteenDailyRecipe);
        }else{
            insCanteenDailyRecipeService.saveInsCanteenDailyRecipe(insCanteenDailyRecipe);
        }
        Map<String,Object> reslut=new HashMap<String,Object>();
        reslut.put("reslutCode", "1");
        reslut.put("reslutMessage", "保存成功!");
        return reslut;
    }
    /**
    *修改对象
    */
    @RequestMapping(value = "/updateInsCanteenDailyRecipe", method = RequestMethod.POST)
    @ResponseBody
    public Map<String,Object> updateInsCanteenDailyRecipe(Integer id){
        InsCanteenDailyRecipe insCanteenDailyRecipe=new InsCanteenDailyRecipe();
        insCanteenDailyRecipe.setId(id);
        insCanteenDailyRecipeService.updateInsCanteenDailyRecipe(insCanteenDailyRecipe);
        Map<String,Object> reslut=new HashMap<String,Object>();
        reslut.put("reslutCode", "1");
        reslut.put("reslutMessage", "保存成功!");
        return reslut;
    }
    /**
    *删除对象
    */
    @RequestMapping(value = "/deleteInsCanteenDailyRecipe", method = RequestMethod.POST)
    @ResponseBody
    public Map<String,Object> deleteInsCanteenDailyRecipe(Integer id){
        InsCanteenDailyRecipe insCanteenDailyRecipe=new InsCanteenDailyRecipe();
        insCanteenDailyRecipe.setId(id);
        insCanteenDailyRecipeService.deleteInsCanteenDailyRecipe(insCanteenDailyRecipe);
        Map<String,Object> reslut=new HashMap<String,Object>();
        reslut.put("reslutCode", "1");
        reslut.put("reslutMessage", "保存成功!");
        return reslut;
    }
    /**
    *批量删除对象
    */
    @RequestMapping(value = "/deleteInsCanteenDailyRecipeBatch", method = RequestMethod.POST)
    @ResponseBody
    public Map<String,Object> deleteInsCanteenDailyRecipeBatch(String[] ids){
        insCanteenDailyRecipeService.deleteInsCanteenDailyRecipeBatch(Arrays.asList(ids));
        Map<String,Object> reslut=new HashMap<String,Object>();
        reslut.put("reslutCode", "1");
        reslut.put("reslutMessage", "保存成功!");
        return reslut;
    }
}
