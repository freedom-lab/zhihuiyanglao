package cn.pluss.platform.controller.InsBaseCostInfo;

import cn.pluss.platform.base.BaseController;
import java.util.Map;
import java.util.List;
import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;
import cn.pluss.platform.util.StringUtil;
import javax.servlet.http.HttpServletRequest;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import cn.pluss.platform.model.entity.InsBaseCostInfo;
import cn.pluss.platform.insBaseCostInfo.InsBaseCostInfoService;

@Controller
@RequestMapping("insBaseCostInfo")
public class InsBaseCostInfoController  extends BaseController{

    private Integer PAGE_SIZE=12;

    @Autowired
    private InsBaseCostInfoService insBaseCostInfoService;

    /**
    *引导页
    * @return
    */
    @RequestMapping(value = "/index", method = RequestMethod.GET)
    public String index(HttpServletRequest request,Integer pageIndex) {
        if(pageIndex==null||pageIndex==0) {
        pageIndex=1;
        }
        request.setAttribute("pageIndex", pageIndex);
        return "insBaseCostInfo/insBaseCostInfoList";
    }

    /**
    *分页查询
    */
    @RequestMapping(value = "/queryInsBaseCostInfoByPage", method = RequestMethod.GET)
    @ResponseBody
    public  Map<String,Object> queryInsBaseCostInfoByPage(Integer page,Integer limit,Integer id) {

        if(page==null) {
        page=1;
        }
        Map<String,Object> map=new HashMap<String, Object>();
        map.put("pageSize",limit);
        map.put("offset",(page-1)*limit);
        map.put("id",  id);
        List<InsBaseCostInfo> insBaseCostInfoList=insBaseCostInfoService.queryPage(map);
        Integer count=insBaseCostInfoService.queryPageCount(map);
        Map<String,Object> reslut=new HashMap<String,Object>();
        reslut.put("code", 0);
        reslut.put("count", count);
        reslut.put("data",insBaseCostInfoList);
        return reslut;
    }
    /**
    *查询详情
    */
    @RequestMapping(value = "/queryInsBaseCostInfoDetails", method = RequestMethod.GET)
    public String queryInsBaseCostInfoDetails(HttpServletRequest request,Integer id,Integer pageIndex){

        if(id!=null&&id!=0) {
        InsBaseCostInfo insBaseCostInfo=new InsBaseCostInfo();
        insBaseCostInfo.setId(id);
        insBaseCostInfo=insBaseCostInfoService.queryInsBaseCostInfo(insBaseCostInfo);
        request.setAttribute("insBaseCostInfo", insBaseCostInfo);
        request.setAttribute("pageIndex", pageIndex);
        }
        return "insBaseCostInfo/insBaseCostInfoDetails";
    }
    /**
    *查询详情
    */
    @RequestMapping(value = "/queryInsBaseCostInfoBaseInfo", method = RequestMethod.GET)
    public String queryInsBaseCostInfoBaseInfo(HttpServletRequest request,Integer id,Integer pageIndex){

        if(id!=null&&id!=0) {
        InsBaseCostInfo insBaseCostInfo=new InsBaseCostInfo();
        insBaseCostInfo.setId(id);
        insBaseCostInfo=insBaseCostInfoService.queryInsBaseCostInfo(insBaseCostInfo);
        request.setAttribute("insBaseCostInfo", insBaseCostInfo);
        request.setAttribute("pageIndex", pageIndex);
        }
        return "insBaseCostInfo/insBaseCostInfoBaseInfo";
    }
    /**
    *查询详情
    */
    @RequestMapping(value = "/queryInsBaseCostInfoExtendsInfo", method = RequestMethod.GET)
    public String queryInsBaseCostInfoExtendsInfo(){

        return "insBaseCostInfo/insBaseCostInfodExtendsInfo";
    }
    /**
    *查询详情
    */
    @RequestMapping(value = "/queryInsBaseCostInfoFunctionsInfo", method = RequestMethod.GET)
    public String queryInsBaseCostInfoFunctionsInfo(){

        return "insBaseCostInfo/insBaseCostInfoFunctionsInfo";
    }
    /**
    *保存对象
    */
    @RequestMapping(value = "/saveInsBaseCostInfo", method = RequestMethod.POST)
    @ResponseBody
    public Map<String,Object> saveInsBaseCostInfo(InsBaseCostInfo insBaseCostInfo){

        if(insBaseCostInfo.getId()!=null&&insBaseCostInfo.getId()!=0){
            insBaseCostInfoService.updateInsBaseCostInfo(insBaseCostInfo);
        }else{
            insBaseCostInfoService.saveInsBaseCostInfo(insBaseCostInfo);
        }
        Map<String,Object> reslut=new HashMap<String,Object>();
        reslut.put("reslutCode", "1");
        reslut.put("reslutMessage", "保存成功!");
        return reslut;
    }
    /**
    *修改对象
    */
    @RequestMapping(value = "/updateInsBaseCostInfo", method = RequestMethod.POST)
    @ResponseBody
    public Map<String,Object> updateInsBaseCostInfo(Integer id){
        InsBaseCostInfo insBaseCostInfo=new InsBaseCostInfo();
        insBaseCostInfo.setId(id);
        insBaseCostInfoService.updateInsBaseCostInfo(insBaseCostInfo);
        Map<String,Object> reslut=new HashMap<String,Object>();
        reslut.put("reslutCode", "1");
        reslut.put("reslutMessage", "保存成功!");
        return reslut;
    }
    /**
    *删除对象
    */
    @RequestMapping(value = "/deleteInsBaseCostInfo", method = RequestMethod.POST)
    @ResponseBody
    public Map<String,Object> deleteInsBaseCostInfo(Integer id){
        InsBaseCostInfo insBaseCostInfo=new InsBaseCostInfo();
        insBaseCostInfo.setId(id);
        insBaseCostInfoService.deleteInsBaseCostInfo(insBaseCostInfo);
        Map<String,Object> reslut=new HashMap<String,Object>();
        reslut.put("reslutCode", "1");
        reslut.put("reslutMessage", "保存成功!");
        return reslut;
    }
    /**
    *批量删除对象
    */
    @RequestMapping(value = "/deleteInsBaseCostInfoBatch", method = RequestMethod.POST)
    @ResponseBody
    public Map<String,Object> deleteInsBaseCostInfoBatch(String[] ids){
        insBaseCostInfoService.deleteInsBaseCostInfoBatch(Arrays.asList(ids));
        Map<String,Object> reslut=new HashMap<String,Object>();
        reslut.put("reslutCode", "1");
        reslut.put("reslutMessage", "保存成功!");
        return reslut;
    }
}
