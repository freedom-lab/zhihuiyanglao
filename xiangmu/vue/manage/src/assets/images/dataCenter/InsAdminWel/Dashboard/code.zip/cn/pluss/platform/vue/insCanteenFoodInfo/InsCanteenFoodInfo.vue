<template>
  <div style="padding:16px">

    <!-- 头部部分 -->
    <div ref="search_d">
      <el-row type="flex" class="row-bg" justify="space-around">
        <el-col :span="18">
          <el-button type="primary" @click="newBtn">新建</el-button>
        </el-col>
        <el-col :span="6">
          <el-input placeholder="请输入内容" v-model="queryInfo.condition.queryKey" class="input-with-select" clearable>
            <el-button slot="append" icon="el-icon-search" @click="getList"></el-button>
          </el-input>
        </el-col>
      </el-row>
    </div>

    <!-- 表格部分 -->
    <div>
      <el-table border ref="table" v-loading="loading" :data="tableData" tooltip-effect="dark" style="width: 100%" :height="height">
        <el-table-column label="序号" type="index" width="50" align="center"></el-table-column>

                  <el-table-column label="主键id" align="center" show-overflow-tooltip>
            <template slot-scope="scope">{{ scope.row.id }}</template>
          </el-table-column>
          <el-table-column label="租户id" align="center" show-overflow-tooltip>
            <template slot-scope="scope">{{ scope.row.tenantId }}</template>
          </el-table-column>
          <el-table-column label="所属运营公司id" align="center" show-overflow-tooltip>
            <template slot-scope="scope">{{ scope.row.corpId }}</template>
          </el-table-column>
          <el-table-column label="所属运营公司名称" align="center" show-overflow-tooltip>
            <template slot-scope="scope">{{ scope.row.corpName }}</template>
          </el-table-column>
          <el-table-column label="机构id" align="center" show-overflow-tooltip>
            <template slot-scope="scope">{{ scope.row.institutionId }}</template>
          </el-table-column>
          <el-table-column label="机构名称" align="center" show-overflow-tooltip>
            <template slot-scope="scope">{{ scope.row.institutionName }}</template>
          </el-table-column>
          <el-table-column label="餐品大类id" align="center" show-overflow-tooltip>
            <template slot-scope="scope">{{ scope.row.typeId }}</template>
          </el-table-column>
          <el-table-column label="餐品大类名称" align="center" show-overflow-tooltip>
            <template slot-scope="scope">{{ scope.row.typeName }}</template>
          </el-table-column>
          <el-table-column label="餐品类型（1单品" align="center" show-overflow-tooltip>
            <template slot-scope="scope">{{ scope.row.isPackage }}</template>
          </el-table-column>
          <el-table-column label="餐品名称" align="center" show-overflow-tooltip>
            <template slot-scope="scope">{{ scope.row.foodName }}</template>
          </el-table-column>
          <el-table-column label="餐品单价(元)" align="center" show-overflow-tooltip>
            <template slot-scope="scope">{{ scope.row.foodPrice }}</template>
          </el-table-column>
          <el-table-column label="餐品单位" align="center" show-overflow-tooltip>
            <template slot-scope="scope">{{ scope.row.foodUnit }}</template>
          </el-table-column>
          <el-table-column label="餐品口味（数据字典多选(food_tastee)）" align="center" show-overflow-tooltip>
            <template slot-scope="scope">{{ scope.row.foodTaste }}</template>
          </el-table-column>
          <el-table-column label="禁忌人群（数据字典多选(food_avoid)）" align="center" show-overflow-tooltip>
            <template slot-scope="scope">{{ scope.row.foodAvoid }}</template>
          </el-table-column>
          <el-table-column label="辣味级别（0不辣1微辣2中辣3特辣）" align="center" show-overflow-tooltip>
            <template slot-scope="scope">{{ scope.row.pungencyDegree }}</template>
          </el-table-column>
          <el-table-column label="营养说明" align="center" show-overflow-tooltip>
            <template slot-scope="scope">{{ scope.row.nutritionDesp }}</template>
          </el-table-column>
          <el-table-column label="食材说明" align="center" show-overflow-tooltip>
            <template slot-scope="scope">{{ scope.row.ingredientDesp }}</template>
          </el-table-column>
          <el-table-column label="餐品简图" align="center" show-overflow-tooltip>
            <template slot-scope="scope">{{ scope.row.foodImg }}</template>
          </el-table-column>
          <el-table-column label="套餐说明(餐品类型是套餐填写)" align="center" show-overflow-tooltip>
            <template slot-scope="scope">{{ scope.row.packageDesp }}</template>
          </el-table-column>
          <el-table-column label="菜品类型（数据字典(ins_recipe_type)）" align="center" show-overflow-tooltip>
            <template slot-scope="scope">{{ scope.row.recipeType }}</template>
          </el-table-column>
          <el-table-column label="适用餐次（数据字典(ins_meal_time_type)）" align="center" show-overflow-tooltip>
            <template slot-scope="scope">{{ scope.row.mealTimeType }}</template>
          </el-table-column>
          <el-table-column label="烹饪方式（数据字典(ins_cooking_method)）" align="center" show-overflow-tooltip>
            <template slot-scope="scope">{{ scope.row.cookingMethod }}</template>
          </el-table-column>
          <el-table-column label="每份成品重量（克）" align="center" show-overflow-tooltip>
            <template slot-scope="scope">{{ scope.row.portionWeight }}</template>
          </el-table-column>
          <el-table-column label="份量描述（如：1碗，约200g）" align="center" show-overflow-tooltip>
            <template slot-scope="scope">{{ scope.row.servingSize }}</template>
          </el-table-column>
          <el-table-column label="总热量（千卡/份）" align="center" show-overflow-tooltip>
            <template slot-scope="scope">{{ scope.row.totalCalorie }}</template>
          </el-table-column>
          <el-table-column label="总蛋白质（克/份）" align="center" show-overflow-tooltip>
            <template slot-scope="scope">{{ scope.row.totalProtein }}</template>
          </el-table-column>
          <el-table-column label="总脂肪（克/份）" align="center" show-overflow-tooltip>
            <template slot-scope="scope">{{ scope.row.totalFat }}</template>
          </el-table-column>
          <el-table-column label="总碳水化合物（克/份）" align="center" show-overflow-tooltip>
            <template slot-scope="scope">{{ scope.row.totalCarbohydrate }}</template>
          </el-table-column>
          <el-table-column label="总膳食纤维（克/份）" align="center" show-overflow-tooltip>
            <template slot-scope="scope">{{ scope.row.totalDietaryFiber }}</template>
          </el-table-column>
          <el-table-column label="总钠（毫克/份）" align="center" show-overflow-tooltip>
            <template slot-scope="scope">{{ scope.row.totalSodium }}</template>
          </el-table-column>
          <el-table-column label="总钾（毫克/份）" align="center" show-overflow-tooltip>
            <template slot-scope="scope">{{ scope.row.totalPotassium }}</template>
          </el-table-column>
          <el-table-column label="总钙（毫克/份）" align="center" show-overflow-tooltip>
            <template slot-scope="scope">{{ scope.row.totalCalcium }}</template>
          </el-table-column>
          <el-table-column label="总镁（毫克/份）" align="center" show-overflow-tooltip>
            <template slot-scope="scope">{{ scope.row.totalMagnesium }}</template>
          </el-table-column>
          <el-table-column label="总磷（毫克/份）" align="center" show-overflow-tooltip>
            <template slot-scope="scope">{{ scope.row.totalPhosphorus }}</template>
          </el-table-column>
          <el-table-column label="总铁（毫克/份）" align="center" show-overflow-tooltip>
            <template slot-scope="scope">{{ scope.row.totalIron }}</template>
          </el-table-column>
          <el-table-column label="总嘌呤（毫克/份）" align="center" show-overflow-tooltip>
            <template slot-scope="scope">{{ scope.row.totalPurine }}</template>
          </el-table-column>
          <el-table-column label="是否高嘌呤食谱：0否" align="center" show-overflow-tooltip>
            <template slot-scope="scope">{{ scope.row.isHighPurine }}</template>
          </el-table-column>
          <el-table-column label="是否高糖食谱：0否" align="center" show-overflow-tooltip>
            <template slot-scope="scope">{{ scope.row.isHighSugar }}</template>
          </el-table-column>
          <el-table-column label="是否高脂食谱：0否" align="center" show-overflow-tooltip>
            <template slot-scope="scope">{{ scope.row.isHighFat }}</template>
          </el-table-column>
          <el-table-column label="禁忌与过敏原说明" align="center" show-overflow-tooltip>
            <template slot-scope="scope">{{ scope.row.tabooExplain }}</template>
          </el-table-column>
          <el-table-column label="餐品简介" align="center" show-overflow-tooltip>
            <template slot-scope="scope">{{ scope.row.remark }}</template>
          </el-table-column>
          <el-table-column label="创建人id" align="center" show-overflow-tooltip>
            <template slot-scope="scope">{{ scope.row.createUser }}</template>
          </el-table-column>
          <el-table-column label="创建人名称" align="center" show-overflow-tooltip>
            <template slot-scope="scope">{{ scope.row.createName }}</template>
          </el-table-column>
          <el-table-column label="创建部门id" align="center" show-overflow-tooltip>
            <template slot-scope="scope">{{ scope.row.createDept }}</template>
          </el-table-column>
          <el-table-column label="创建时间" align="center" show-overflow-tooltip>
            <template slot-scope="scope">{{ scope.row.createTime }}</template>
          </el-table-column>
          <el-table-column label="修改人id" align="center" show-overflow-tooltip>
            <template slot-scope="scope">{{ scope.row.updateUser }}</template>
          </el-table-column>
          <el-table-column label="修改时间" align="center" show-overflow-tooltip>
            <template slot-scope="scope">{{ scope.row.updateTime }}</template>
          </el-table-column>
          <el-table-column label="是否已删除(0未删除" align="center" show-overflow-tooltip>
            <template slot-scope="scope">{{ scope.row.isDeleted }}</template>
          </el-table-column>
          <el-table-column label="上架状态(0下架1上架)" align="center" show-overflow-tooltip>
            <template slot-scope="scope">{{ scope.row.status }}</template>
          </el-table-column>
        <el-table-column label="操作" width="135" align="center">
          <template slot-scope="scope">
            <el-button type="text" @click="edit(scope.row)" size="small">编辑</el-button>
            <el-popconfirm title="确定删除吗？" @confirm="handleDelte(scope.row.id)">
              <el-button slot="reference" type="text">删除</el-button>
            </el-popconfirm>
          </template>
        </el-table-column>
      </el-table>
      <!-- 分页 -->
      <div class="block">
        <el-pagination @size-change="handleSizeChange" @current-change="handleCurrentChange"
          :current-page="queryInfo.currPage" :page-sizes="[100, 200, 300, 400]" :page-size="queryInfo.pageSize"
          layout="total, sizes, prev, pager, next, jumper" :total="total">
        </el-pagination>
      </div>
    </div>

    <el-dialog :title="(labelType=='add'?'新增':'编辑')" :visible.sync="showDialog" width="800px">
      <el-form ref="form" :model="form" :rules="rules" label-width="120px">
        <el-row :gutter="10">

            <el-col :span="12">
              <el-form-item label="主键id：" prop="siteName">
                <el-input v-model="form.id" placeholder="请输入名称"></el-input>
              </el-form-item>
            </el-col>
            <el-col :span="12">
              <el-form-item label="租户id：" prop="siteName">
                <el-input v-model="form.tenantId" placeholder="请输入名称"></el-input>
              </el-form-item>
            </el-col>
            <el-col :span="12">
              <el-form-item label="所属运营公司id：" prop="siteName">
                <el-input v-model="form.corpId" placeholder="请输入名称"></el-input>
              </el-form-item>
            </el-col>
            <el-col :span="12">
              <el-form-item label="所属运营公司名称：" prop="siteName">
                <el-input v-model="form.corpName" placeholder="请输入名称"></el-input>
              </el-form-item>
            </el-col>
            <el-col :span="12">
              <el-form-item label="机构id：" prop="siteName">
                <el-input v-model="form.institutionId" placeholder="请输入名称"></el-input>
              </el-form-item>
            </el-col>
            <el-col :span="12">
              <el-form-item label="机构名称：" prop="siteName">
                <el-input v-model="form.institutionName" placeholder="请输入名称"></el-input>
              </el-form-item>
            </el-col>
            <el-col :span="12">
              <el-form-item label="餐品大类id：" prop="siteName">
                <el-input v-model="form.typeId" placeholder="请输入名称"></el-input>
              </el-form-item>
            </el-col>
            <el-col :span="12">
              <el-form-item label="餐品大类名称：" prop="siteName">
                <el-input v-model="form.typeName" placeholder="请输入名称"></el-input>
              </el-form-item>
            </el-col>
            <el-col :span="12">
              <el-form-item label="餐品类型（1单品：" prop="siteName">
                <el-input v-model="form.isPackage" placeholder="请输入名称"></el-input>
              </el-form-item>
            </el-col>
            <el-col :span="12">
              <el-form-item label="餐品名称：" prop="siteName">
                <el-input v-model="form.foodName" placeholder="请输入名称"></el-input>
              </el-form-item>
            </el-col>
            <el-col :span="12">
              <el-form-item label="餐品单价(元)：" prop="siteName">
                <el-input v-model="form.foodPrice" placeholder="请输入名称"></el-input>
              </el-form-item>
            </el-col>
            <el-col :span="12">
              <el-form-item label="餐品单位：" prop="siteName">
                <el-input v-model="form.foodUnit" placeholder="请输入名称"></el-input>
              </el-form-item>
            </el-col>
            <el-col :span="12">
              <el-form-item label="餐品口味（数据字典多选(food_tastee)）：" prop="siteName">
                <el-input v-model="form.foodTaste" placeholder="请输入名称"></el-input>
              </el-form-item>
            </el-col>
            <el-col :span="12">
              <el-form-item label="禁忌人群（数据字典多选(food_avoid)）：" prop="siteName">
                <el-input v-model="form.foodAvoid" placeholder="请输入名称"></el-input>
              </el-form-item>
            </el-col>
            <el-col :span="12">
              <el-form-item label="辣味级别（0不辣1微辣2中辣3特辣）：" prop="siteName">
                <el-input v-model="form.pungencyDegree" placeholder="请输入名称"></el-input>
              </el-form-item>
            </el-col>
            <el-col :span="12">
              <el-form-item label="营养说明：" prop="siteName">
                <el-input v-model="form.nutritionDesp" placeholder="请输入名称"></el-input>
              </el-form-item>
            </el-col>
            <el-col :span="12">
              <el-form-item label="食材说明：" prop="siteName">
                <el-input v-model="form.ingredientDesp" placeholder="请输入名称"></el-input>
              </el-form-item>
            </el-col>
            <el-col :span="12">
              <el-form-item label="餐品简图：" prop="siteName">
                <el-input v-model="form.foodImg" placeholder="请输入名称"></el-input>
              </el-form-item>
            </el-col>
            <el-col :span="12">
              <el-form-item label="套餐说明(餐品类型是套餐填写)：" prop="siteName">
                <el-input v-model="form.packageDesp" placeholder="请输入名称"></el-input>
              </el-form-item>
            </el-col>
            <el-col :span="12">
              <el-form-item label="菜品类型（数据字典(ins_recipe_type)）：" prop="siteName">
                <el-input v-model="form.recipeType" placeholder="请输入名称"></el-input>
              </el-form-item>
            </el-col>
            <el-col :span="12">
              <el-form-item label="适用餐次（数据字典(ins_meal_time_type)）：" prop="siteName">
                <el-input v-model="form.mealTimeType" placeholder="请输入名称"></el-input>
              </el-form-item>
            </el-col>
            <el-col :span="12">
              <el-form-item label="烹饪方式（数据字典(ins_cooking_method)）：" prop="siteName">
                <el-input v-model="form.cookingMethod" placeholder="请输入名称"></el-input>
              </el-form-item>
            </el-col>
            <el-col :span="12">
              <el-form-item label="每份成品重量（克）：" prop="siteName">
                <el-input v-model="form.portionWeight" placeholder="请输入名称"></el-input>
              </el-form-item>
            </el-col>
            <el-col :span="12">
              <el-form-item label="份量描述（如：1碗，约200g）：" prop="siteName">
                <el-input v-model="form.servingSize" placeholder="请输入名称"></el-input>
              </el-form-item>
            </el-col>
            <el-col :span="12">
              <el-form-item label="总热量（千卡/份）：" prop="siteName">
                <el-input v-model="form.totalCalorie" placeholder="请输入名称"></el-input>
              </el-form-item>
            </el-col>
            <el-col :span="12">
              <el-form-item label="总蛋白质（克/份）：" prop="siteName">
                <el-input v-model="form.totalProtein" placeholder="请输入名称"></el-input>
              </el-form-item>
            </el-col>
            <el-col :span="12">
              <el-form-item label="总脂肪（克/份）：" prop="siteName">
                <el-input v-model="form.totalFat" placeholder="请输入名称"></el-input>
              </el-form-item>
            </el-col>
            <el-col :span="12">
              <el-form-item label="总碳水化合物（克/份）：" prop="siteName">
                <el-input v-model="form.totalCarbohydrate" placeholder="请输入名称"></el-input>
              </el-form-item>
            </el-col>
            <el-col :span="12">
              <el-form-item label="总膳食纤维（克/份）：" prop="siteName">
                <el-input v-model="form.totalDietaryFiber" placeholder="请输入名称"></el-input>
              </el-form-item>
            </el-col>
            <el-col :span="12">
              <el-form-item label="总钠（毫克/份）：" prop="siteName">
                <el-input v-model="form.totalSodium" placeholder="请输入名称"></el-input>
              </el-form-item>
            </el-col>
            <el-col :span="12">
              <el-form-item label="总钾（毫克/份）：" prop="siteName">
                <el-input v-model="form.totalPotassium" placeholder="请输入名称"></el-input>
              </el-form-item>
            </el-col>
            <el-col :span="12">
              <el-form-item label="总钙（毫克/份）：" prop="siteName">
                <el-input v-model="form.totalCalcium" placeholder="请输入名称"></el-input>
              </el-form-item>
            </el-col>
            <el-col :span="12">
              <el-form-item label="总镁（毫克/份）：" prop="siteName">
                <el-input v-model="form.totalMagnesium" placeholder="请输入名称"></el-input>
              </el-form-item>
            </el-col>
            <el-col :span="12">
              <el-form-item label="总磷（毫克/份）：" prop="siteName">
                <el-input v-model="form.totalPhosphorus" placeholder="请输入名称"></el-input>
              </el-form-item>
            </el-col>
            <el-col :span="12">
              <el-form-item label="总铁（毫克/份）：" prop="siteName">
                <el-input v-model="form.totalIron" placeholder="请输入名称"></el-input>
              </el-form-item>
            </el-col>
            <el-col :span="12">
              <el-form-item label="总嘌呤（毫克/份）：" prop="siteName">
                <el-input v-model="form.totalPurine" placeholder="请输入名称"></el-input>
              </el-form-item>
            </el-col>
            <el-col :span="12">
              <el-form-item label="是否高嘌呤食谱：0否：" prop="siteName">
                <el-input v-model="form.isHighPurine" placeholder="请输入名称"></el-input>
              </el-form-item>
            </el-col>
            <el-col :span="12">
              <el-form-item label="是否高糖食谱：0否：" prop="siteName">
                <el-input v-model="form.isHighSugar" placeholder="请输入名称"></el-input>
              </el-form-item>
            </el-col>
            <el-col :span="12">
              <el-form-item label="是否高脂食谱：0否：" prop="siteName">
                <el-input v-model="form.isHighFat" placeholder="请输入名称"></el-input>
              </el-form-item>
            </el-col>
            <el-col :span="12">
              <el-form-item label="禁忌与过敏原说明：" prop="siteName">
                <el-input v-model="form.tabooExplain" placeholder="请输入名称"></el-input>
              </el-form-item>
            </el-col>
            <el-col :span="12">
              <el-form-item label="餐品简介：" prop="siteName">
                <el-input v-model="form.remark" placeholder="请输入名称"></el-input>
              </el-form-item>
            </el-col>
            <el-col :span="12">
              <el-form-item label="创建人id：" prop="siteName">
                <el-input v-model="form.createUser" placeholder="请输入名称"></el-input>
              </el-form-item>
            </el-col>
            <el-col :span="12">
              <el-form-item label="创建人名称：" prop="siteName">
                <el-input v-model="form.createName" placeholder="请输入名称"></el-input>
              </el-form-item>
            </el-col>
            <el-col :span="12">
              <el-form-item label="创建部门id：" prop="siteName">
                <el-input v-model="form.createDept" placeholder="请输入名称"></el-input>
              </el-form-item>
            </el-col>
            <el-col :span="12">
              <el-form-item label="创建时间：" prop="siteName">
                <el-input v-model="form.createTime" placeholder="请输入名称"></el-input>
              </el-form-item>
            </el-col>
            <el-col :span="12">
              <el-form-item label="修改人id：" prop="siteName">
                <el-input v-model="form.updateUser" placeholder="请输入名称"></el-input>
              </el-form-item>
            </el-col>
            <el-col :span="12">
              <el-form-item label="修改时间：" prop="siteName">
                <el-input v-model="form.updateTime" placeholder="请输入名称"></el-input>
              </el-form-item>
            </el-col>
            <el-col :span="12">
              <el-form-item label="是否已删除(0未删除：" prop="siteName">
                <el-input v-model="form.isDeleted" placeholder="请输入名称"></el-input>
              </el-form-item>
            </el-col>
            <el-col :span="12">
              <el-form-item label="上架状态(0下架1上架)：" prop="siteName">
                <el-input v-model="form.status" placeholder="请输入名称"></el-input>
              </el-form-item>
            </el-col>
        </el-row>
      </el-form>
      <span slot="footer">
        <el-button size="small" @click="showDialog = false">取消</el-button>
        <el-button size="small" type="primary" @click="handleSave">确定</el-button>
      </span>
    </el-dialog>
  </div>
</template>

<script>
export default {
  data () {
    return {
      labelType: 'add',
      rules: {},
      total: 0,
      queryInfo: {
        pageSize: 100,
        pageCount: 1,
        currPage: 1,
        condition: {}
      },
      form: {},
      showDialog: false,
      tableData: [],
      height: window.innerHeight - 256, //表格高度
      headerHeight: 0,
      loading:false
    };
  },

  created () {
    this.getList()
  },

  mounted () {
    this.$nextTick(() => {
      // 获取定义ref属性 和 元素高度
      this.headerHeight = this.$refs.search_d.offsetHeight;
      window.addEventListener('resize', this.getHeight())
    })
  },

  methods: {
    // 监听表格高度
    getHeight () {
      this.height = window.innerHeight - this.headerHeight - 256;
    },

    //获取数据
    getList () {
	  var that = this;
    that.loading = true
	  that.$http.post("/insCanteenFoodInfo/list", that.queryInfo).then(function (response) {
        console.log(response.data.data);
        if (response.data.code == 200) {
          that.loading = false
          that.total = response.data.data.count;
          that.queryInfo.currPage=response.data.data.currPage
          that.tableData = response.data.data.data;
        }
      });
    },

    // 保存
    handleSave () {
	    var that = this;
	  that.$http.post("/insCanteenFoodInfo/save", that.form).then(function (response) {
		  if (response.data.code == 200) {
			  that.$notify.success({
				title: "提示",
				message: "保存成功",
				showClose: true,
			  });
			 that.showDialog = false
			  that.getList()
		  }else{
			  that.$notify.info({
				title: "提示",
				message: response.data.message,
				showClose: true,
			  });
		  }
      }).catch(function(error){


      })
	  
	  
    },

    //修改
    edit (row) {
      this.showDialog = true;
      this.labelType = 'edit'
      this.form = JSON.parse(JSON.stringify(row))
    },

    // 删除当前行
//    handleDelte (id) {
//      del({ id: id }).then(res => {
//        if (res.code == 200) {
 //         this.$message.success('删除成功')
 //         this.getList()
 //       }
//      })
//    },
	
	// 删除用户
    async handleDelte(id) {
      const confirmResult = await this.$confirm("确定删除吗?", "提示", {
        confirmButtonText: "确定",
        cancelButtonText: "取消",
        type: "warning",
      }).catch((err) => err);
      if (confirmResult === "confirm") {
           var that = this;
        that.$http.post("/insCanteenFoodInfo/delete" ,{"id":id}).then(function (response) {
			if(response.data.code == 200){
			 that.$notify.success({
				title: "提示",
				message: "删除成功",
				showClose: true,
			  });
			  that.getList();
			}else{
				 that.$notify.info({
					title: "提示",
					message: response.data.message,
					showClose: true,
				  });
			}
         
        });
      }
    },

    //新增按钮
    newBtn () {
      this.labelType = 'add'
      this.showDialog = true;
      this.form = {}
    },

    // 修改页数大小
    handleSizeChange (val) {
      this.queryInfo.pageSize = val;
      this.getList()
    },

    // 获取当前页面
    handleCurrentChange (val) {
      this.queryInfo.currPage = val;
      this.getList()
    },

  },
};
</script>

<style scoped>
</style>

