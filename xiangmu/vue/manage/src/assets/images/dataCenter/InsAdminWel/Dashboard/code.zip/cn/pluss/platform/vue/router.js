
    const InsCanteenDailyRecipe = () => import('../views/insCanteenDailyRecipe/InsCanteenDailyRecipe.vue')
    const InsCanteenFoodInfo = () => import('../views/insCanteenFoodInfo/InsCanteenFoodInfo.vue')
    const InsCanteenFoodMaterial = () => import('../views/insCanteenFoodMaterial/InsCanteenFoodMaterial.vue')
    const InsCanteenWeekMenu = () => import('../views/insCanteenWeekMenu/InsCanteenWeekMenu.vue')
    const InsCanteenWeekMenuDetail = () => import('../views/insCanteenWeekMenuDetail/InsCanteenWeekMenuDetail.vue')

    { path: '/insCanteenDailyRecipe', component: InsCanteenDailyRecipe },
    { path: '/insCanteenFoodInfo', component: InsCanteenFoodInfo },
    { path: '/insCanteenFoodMaterial', component: InsCanteenFoodMaterial },
    { path: '/insCanteenWeekMenu', component: InsCanteenWeekMenu },
    { path: '/insCanteenWeekMenuDetail', component: InsCanteenWeekMenuDetail },





