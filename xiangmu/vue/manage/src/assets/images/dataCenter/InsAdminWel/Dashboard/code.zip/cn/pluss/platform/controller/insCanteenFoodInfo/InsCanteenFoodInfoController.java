package cn.pluss.platform.controller.InsCanteenFoodInfo;

import cn.pluss.platform.base.BaseController;
import java.util.Map;
import java.util.List;
import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;
import cn.pluss.platform.util.StringUtil;
import javax.servlet.http.HttpServletRequest;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import cn.pluss.platform.model.entity.InsCanteenFoodInfo;
import cn.pluss.platform.insCanteenFoodInfo.InsCanteenFoodInfoService;

@Controller
@RequestMapping("insCanteenFoodInfo")
public class InsCanteenFoodInfoController  extends BaseController{

    private Integer PAGE_SIZE=12;

    @Autowired
    private InsCanteenFoodInfoService insCanteenFoodInfoService;

    /**
    *引导页
    * @return
    */
    @RequestMapping(value = "/index", method = RequestMethod.GET)
    public String index(HttpServletRequest request,Integer pageIndex) {
        if(pageIndex==null||pageIndex==0) {
        pageIndex=1;
        }
        request.setAttribute("pageIndex", pageIndex);
        return "insCanteenFoodInfo/insCanteenFoodInfoList";
    }

    /**
    *分页查询
    */
    @RequestMapping(value = "/queryInsCanteenFoodInfoByPage", method = RequestMethod.GET)
    @ResponseBody
    public  Map<String,Object> queryInsCanteenFoodInfoByPage(Integer page,Integer limit,Integer id) {

        if(page==null) {
        page=1;
        }
        Map<String,Object> map=new HashMap<String, Object>();
        map.put("pageSize",limit);
        map.put("offset",(page-1)*limit);
        map.put("id",  id);
        List<InsCanteenFoodInfo> insCanteenFoodInfoList=insCanteenFoodInfoService.queryPage(map);
        Integer count=insCanteenFoodInfoService.queryPageCount(map);
        Map<String,Object> reslut=new HashMap<String,Object>();
        reslut.put("code", 0);
        reslut.put("count", count);
        reslut.put("data",insCanteenFoodInfoList);
        return reslut;
    }
    /**
    *查询详情
    */
    @RequestMapping(value = "/queryInsCanteenFoodInfoDetails", method = RequestMethod.GET)
    public String queryInsCanteenFoodInfoDetails(HttpServletRequest request,Integer id,Integer pageIndex){

        if(id!=null&&id!=0) {
        InsCanteenFoodInfo insCanteenFoodInfo=new InsCanteenFoodInfo();
        insCanteenFoodInfo.setId(id);
        insCanteenFoodInfo=insCanteenFoodInfoService.queryInsCanteenFoodInfo(insCanteenFoodInfo);
        request.setAttribute("insCanteenFoodInfo", insCanteenFoodInfo);
        request.setAttribute("pageIndex", pageIndex);
        }
        return "insCanteenFoodInfo/insCanteenFoodInfoDetails";
    }
    /**
    *查询详情
    */
    @RequestMapping(value = "/queryInsCanteenFoodInfoBaseInfo", method = RequestMethod.GET)
    public String queryInsCanteenFoodInfoBaseInfo(HttpServletRequest request,Integer id,Integer pageIndex){

        if(id!=null&&id!=0) {
        InsCanteenFoodInfo insCanteenFoodInfo=new InsCanteenFoodInfo();
        insCanteenFoodInfo.setId(id);
        insCanteenFoodInfo=insCanteenFoodInfoService.queryInsCanteenFoodInfo(insCanteenFoodInfo);
        request.setAttribute("insCanteenFoodInfo", insCanteenFoodInfo);
        request.setAttribute("pageIndex", pageIndex);
        }
        return "insCanteenFoodInfo/insCanteenFoodInfoBaseInfo";
    }
    /**
    *查询详情
    */
    @RequestMapping(value = "/queryInsCanteenFoodInfoExtendsInfo", method = RequestMethod.GET)
    public String queryInsCanteenFoodInfoExtendsInfo(){

        return "insCanteenFoodInfo/insCanteenFoodInfodExtendsInfo";
    }
    /**
    *查询详情
    */
    @RequestMapping(value = "/queryInsCanteenFoodInfoFunctionsInfo", method = RequestMethod.GET)
    public String queryInsCanteenFoodInfoFunctionsInfo(){

        return "insCanteenFoodInfo/insCanteenFoodInfoFunctionsInfo";
    }
    /**
    *保存对象
    */
    @RequestMapping(value = "/saveInsCanteenFoodInfo", method = RequestMethod.POST)
    @ResponseBody
    public Map<String,Object> saveInsCanteenFoodInfo(InsCanteenFoodInfo insCanteenFoodInfo){

        if(insCanteenFoodInfo.getId()!=null&&insCanteenFoodInfo.getId()!=0){
            insCanteenFoodInfoService.updateInsCanteenFoodInfo(insCanteenFoodInfo);
        }else{
            insCanteenFoodInfoService.saveInsCanteenFoodInfo(insCanteenFoodInfo);
        }
        Map<String,Object> reslut=new HashMap<String,Object>();
        reslut.put("reslutCode", "1");
        reslut.put("reslutMessage", "保存成功!");
        return reslut;
    }
    /**
    *修改对象
    */
    @RequestMapping(value = "/updateInsCanteenFoodInfo", method = RequestMethod.POST)
    @ResponseBody
    public Map<String,Object> updateInsCanteenFoodInfo(Integer id){
        InsCanteenFoodInfo insCanteenFoodInfo=new InsCanteenFoodInfo();
        insCanteenFoodInfo.setId(id);
        insCanteenFoodInfoService.updateInsCanteenFoodInfo(insCanteenFoodInfo);
        Map<String,Object> reslut=new HashMap<String,Object>();
        reslut.put("reslutCode", "1");
        reslut.put("reslutMessage", "保存成功!");
        return reslut;
    }
    /**
    *删除对象
    */
    @RequestMapping(value = "/deleteInsCanteenFoodInfo", method = RequestMethod.POST)
    @ResponseBody
    public Map<String,Object> deleteInsCanteenFoodInfo(Integer id){
        InsCanteenFoodInfo insCanteenFoodInfo=new InsCanteenFoodInfo();
        insCanteenFoodInfo.setId(id);
        insCanteenFoodInfoService.deleteInsCanteenFoodInfo(insCanteenFoodInfo);
        Map<String,Object> reslut=new HashMap<String,Object>();
        reslut.put("reslutCode", "1");
        reslut.put("reslutMessage", "保存成功!");
        return reslut;
    }
    /**
    *批量删除对象
    */
    @RequestMapping(value = "/deleteInsCanteenFoodInfoBatch", method = RequestMethod.POST)
    @ResponseBody
    public Map<String,Object> deleteInsCanteenFoodInfoBatch(String[] ids){
        insCanteenFoodInfoService.deleteInsCanteenFoodInfoBatch(Arrays.asList(ids));
        Map<String,Object> reslut=new HashMap<String,Object>();
        reslut.put("reslutCode", "1");
        reslut.put("reslutMessage", "保存成功!");
        return reslut;
    }
}
