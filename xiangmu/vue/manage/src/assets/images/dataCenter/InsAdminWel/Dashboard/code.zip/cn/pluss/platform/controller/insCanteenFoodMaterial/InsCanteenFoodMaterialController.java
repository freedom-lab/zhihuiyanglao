package cn.pluss.platform.controller.InsCanteenFoodMaterial;

import cn.pluss.platform.base.BaseController;
import java.util.Map;
import java.util.List;
import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;
import cn.pluss.platform.util.StringUtil;
import javax.servlet.http.HttpServletRequest;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import cn.pluss.platform.model.entity.InsCanteenFoodMaterial;
import cn.pluss.platform.insCanteenFoodMaterial.InsCanteenFoodMaterialService;

@Controller
@RequestMapping("insCanteenFoodMaterial")
public class InsCanteenFoodMaterialController  extends BaseController{

    private Integer PAGE_SIZE=12;

    @Autowired
    private InsCanteenFoodMaterialService insCanteenFoodMaterialService;

    /**
    *引导页
    * @return
    */
    @RequestMapping(value = "/index", method = RequestMethod.GET)
    public String index(HttpServletRequest request,Integer pageIndex) {
        if(pageIndex==null||pageIndex==0) {
        pageIndex=1;
        }
        request.setAttribute("pageIndex", pageIndex);
        return "insCanteenFoodMaterial/insCanteenFoodMaterialList";
    }

    /**
    *分页查询
    */
    @RequestMapping(value = "/queryInsCanteenFoodMaterialByPage", method = RequestMethod.GET)
    @ResponseBody
    public  Map<String,Object> queryInsCanteenFoodMaterialByPage(Integer page,Integer limit,Integer id) {

        if(page==null) {
        page=1;
        }
        Map<String,Object> map=new HashMap<String, Object>();
        map.put("pageSize",limit);
        map.put("offset",(page-1)*limit);
        map.put("id",  id);
        List<InsCanteenFoodMaterial> insCanteenFoodMaterialList=insCanteenFoodMaterialService.queryPage(map);
        Integer count=insCanteenFoodMaterialService.queryPageCount(map);
        Map<String,Object> reslut=new HashMap<String,Object>();
        reslut.put("code", 0);
        reslut.put("count", count);
        reslut.put("data",insCanteenFoodMaterialList);
        return reslut;
    }
    /**
    *查询详情
    */
    @RequestMapping(value = "/queryInsCanteenFoodMaterialDetails", method = RequestMethod.GET)
    public String queryInsCanteenFoodMaterialDetails(HttpServletRequest request,Integer id,Integer pageIndex){

        if(id!=null&&id!=0) {
        InsCanteenFoodMaterial insCanteenFoodMaterial=new InsCanteenFoodMaterial();
        insCanteenFoodMaterial.setId(id);
        insCanteenFoodMaterial=insCanteenFoodMaterialService.queryInsCanteenFoodMaterial(insCanteenFoodMaterial);
        request.setAttribute("insCanteenFoodMaterial", insCanteenFoodMaterial);
        request.setAttribute("pageIndex", pageIndex);
        }
        return "insCanteenFoodMaterial/insCanteenFoodMaterialDetails";
    }
    /**
    *查询详情
    */
    @RequestMapping(value = "/queryInsCanteenFoodMaterialBaseInfo", method = RequestMethod.GET)
    public String queryInsCanteenFoodMaterialBaseInfo(HttpServletRequest request,Integer id,Integer pageIndex){

        if(id!=null&&id!=0) {
        InsCanteenFoodMaterial insCanteenFoodMaterial=new InsCanteenFoodMaterial();
        insCanteenFoodMaterial.setId(id);
        insCanteenFoodMaterial=insCanteenFoodMaterialService.queryInsCanteenFoodMaterial(insCanteenFoodMaterial);
        request.setAttribute("insCanteenFoodMaterial", insCanteenFoodMaterial);
        request.setAttribute("pageIndex", pageIndex);
        }
        return "insCanteenFoodMaterial/insCanteenFoodMaterialBaseInfo";
    }
    /**
    *查询详情
    */
    @RequestMapping(value = "/queryInsCanteenFoodMaterialExtendsInfo", method = RequestMethod.GET)
    public String queryInsCanteenFoodMaterialExtendsInfo(){

        return "insCanteenFoodMaterial/insCanteenFoodMaterialdExtendsInfo";
    }
    /**
    *查询详情
    */
    @RequestMapping(value = "/queryInsCanteenFoodMaterialFunctionsInfo", method = RequestMethod.GET)
    public String queryInsCanteenFoodMaterialFunctionsInfo(){

        return "insCanteenFoodMaterial/insCanteenFoodMaterialFunctionsInfo";
    }
    /**
    *保存对象
    */
    @RequestMapping(value = "/saveInsCanteenFoodMaterial", method = RequestMethod.POST)
    @ResponseBody
    public Map<String,Object> saveInsCanteenFoodMaterial(InsCanteenFoodMaterial insCanteenFoodMaterial){

        if(insCanteenFoodMaterial.getId()!=null&&insCanteenFoodMaterial.getId()!=0){
            insCanteenFoodMaterialService.updateInsCanteenFoodMaterial(insCanteenFoodMaterial);
        }else{
            insCanteenFoodMaterialService.saveInsCanteenFoodMaterial(insCanteenFoodMaterial);
        }
        Map<String,Object> reslut=new HashMap<String,Object>();
        reslut.put("reslutCode", "1");
        reslut.put("reslutMessage", "保存成功!");
        return reslut;
    }
    /**
    *修改对象
    */
    @RequestMapping(value = "/updateInsCanteenFoodMaterial", method = RequestMethod.POST)
    @ResponseBody
    public Map<String,Object> updateInsCanteenFoodMaterial(Integer id){
        InsCanteenFoodMaterial insCanteenFoodMaterial=new InsCanteenFoodMaterial();
        insCanteenFoodMaterial.setId(id);
        insCanteenFoodMaterialService.updateInsCanteenFoodMaterial(insCanteenFoodMaterial);
        Map<String,Object> reslut=new HashMap<String,Object>();
        reslut.put("reslutCode", "1");
        reslut.put("reslutMessage", "保存成功!");
        return reslut;
    }
    /**
    *删除对象
    */
    @RequestMapping(value = "/deleteInsCanteenFoodMaterial", method = RequestMethod.POST)
    @ResponseBody
    public Map<String,Object> deleteInsCanteenFoodMaterial(Integer id){
        InsCanteenFoodMaterial insCanteenFoodMaterial=new InsCanteenFoodMaterial();
        insCanteenFoodMaterial.setId(id);
        insCanteenFoodMaterialService.deleteInsCanteenFoodMaterial(insCanteenFoodMaterial);
        Map<String,Object> reslut=new HashMap<String,Object>();
        reslut.put("reslutCode", "1");
        reslut.put("reslutMessage", "保存成功!");
        return reslut;
    }
    /**
    *批量删除对象
    */
    @RequestMapping(value = "/deleteInsCanteenFoodMaterialBatch", method = RequestMethod.POST)
    @ResponseBody
    public Map<String,Object> deleteInsCanteenFoodMaterialBatch(String[] ids){
        insCanteenFoodMaterialService.deleteInsCanteenFoodMaterialBatch(Arrays.asList(ids));
        Map<String,Object> reslut=new HashMap<String,Object>();
        reslut.put("reslutCode", "1");
        reslut.put("reslutMessage", "保存成功!");
        return reslut;
    }
}
