package cn.pluss.platform.controller.InsCanteenWeekMenuDetail;

import cn.pluss.platform.base.BaseController;
import java.util.Map;
import java.util.List;
import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;
import cn.pluss.platform.util.StringUtil;
import javax.servlet.http.HttpServletRequest;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import cn.pluss.platform.model.entity.InsCanteenWeekMenuDetail;
import cn.pluss.platform.insCanteenWeekMenuDetail.InsCanteenWeekMenuDetailService;

@Controller
@RequestMapping("insCanteenWeekMenuDetail")
public class InsCanteenWeekMenuDetailController  extends BaseController{

    private Integer PAGE_SIZE=12;

    @Autowired
    private InsCanteenWeekMenuDetailService insCanteenWeekMenuDetailService;

    /**
    *引导页
    * @return
    */
    @RequestMapping(value = "/index", method = RequestMethod.GET)
    public String index(HttpServletRequest request,Integer pageIndex) {
        if(pageIndex==null||pageIndex==0) {
        pageIndex=1;
        }
        request.setAttribute("pageIndex", pageIndex);
        return "insCanteenWeekMenuDetail/insCanteenWeekMenuDetailList";
    }

    /**
    *分页查询
    */
    @RequestMapping(value = "/queryInsCanteenWeekMenuDetailByPage", method = RequestMethod.GET)
    @ResponseBody
    public  Map<String,Object> queryInsCanteenWeekMenuDetailByPage(Integer page,Integer limit,Integer id) {

        if(page==null) {
        page=1;
        }
        Map<String,Object> map=new HashMap<String, Object>();
        map.put("pageSize",limit);
        map.put("offset",(page-1)*limit);
        map.put("id",  id);
        List<InsCanteenWeekMenuDetail> insCanteenWeekMenuDetailList=insCanteenWeekMenuDetailService.queryPage(map);
        Integer count=insCanteenWeekMenuDetailService.queryPageCount(map);
        Map<String,Object> reslut=new HashMap<String,Object>();
        reslut.put("code", 0);
        reslut.put("count", count);
        reslut.put("data",insCanteenWeekMenuDetailList);
        return reslut;
    }
    /**
    *查询详情
    */
    @RequestMapping(value = "/queryInsCanteenWeekMenuDetailDetails", method = RequestMethod.GET)
    public String queryInsCanteenWeekMenuDetailDetails(HttpServletRequest request,Integer id,Integer pageIndex){

        if(id!=null&&id!=0) {
        InsCanteenWeekMenuDetail insCanteenWeekMenuDetail=new InsCanteenWeekMenuDetail();
        insCanteenWeekMenuDetail.setId(id);
        insCanteenWeekMenuDetail=insCanteenWeekMenuDetailService.queryInsCanteenWeekMenuDetail(insCanteenWeekMenuDetail);
        request.setAttribute("insCanteenWeekMenuDetail", insCanteenWeekMenuDetail);
        request.setAttribute("pageIndex", pageIndex);
        }
        return "insCanteenWeekMenuDetail/insCanteenWeekMenuDetailDetails";
    }
    /**
    *查询详情
    */
    @RequestMapping(value = "/queryInsCanteenWeekMenuDetailBaseInfo", method = RequestMethod.GET)
    public String queryInsCanteenWeekMenuDetailBaseInfo(HttpServletRequest request,Integer id,Integer pageIndex){

        if(id!=null&&id!=0) {
        InsCanteenWeekMenuDetail insCanteenWeekMenuDetail=new InsCanteenWeekMenuDetail();
        insCanteenWeekMenuDetail.setId(id);
        insCanteenWeekMenuDetail=insCanteenWeekMenuDetailService.queryInsCanteenWeekMenuDetail(insCanteenWeekMenuDetail);
        request.setAttribute("insCanteenWeekMenuDetail", insCanteenWeekMenuDetail);
        request.setAttribute("pageIndex", pageIndex);
        }
        return "insCanteenWeekMenuDetail/insCanteenWeekMenuDetailBaseInfo";
    }
    /**
    *查询详情
    */
    @RequestMapping(value = "/queryInsCanteenWeekMenuDetailExtendsInfo", method = RequestMethod.GET)
    public String queryInsCanteenWeekMenuDetailExtendsInfo(){

        return "insCanteenWeekMenuDetail/insCanteenWeekMenuDetaildExtendsInfo";
    }
    /**
    *查询详情
    */
    @RequestMapping(value = "/queryInsCanteenWeekMenuDetailFunctionsInfo", method = RequestMethod.GET)
    public String queryInsCanteenWeekMenuDetailFunctionsInfo(){

        return "insCanteenWeekMenuDetail/insCanteenWeekMenuDetailFunctionsInfo";
    }
    /**
    *保存对象
    */
    @RequestMapping(value = "/saveInsCanteenWeekMenuDetail", method = RequestMethod.POST)
    @ResponseBody
    public Map<String,Object> saveInsCanteenWeekMenuDetail(InsCanteenWeekMenuDetail insCanteenWeekMenuDetail){

        if(insCanteenWeekMenuDetail.getId()!=null&&insCanteenWeekMenuDetail.getId()!=0){
            insCanteenWeekMenuDetailService.updateInsCanteenWeekMenuDetail(insCanteenWeekMenuDetail);
        }else{
            insCanteenWeekMenuDetailService.saveInsCanteenWeekMenuDetail(insCanteenWeekMenuDetail);
        }
        Map<String,Object> reslut=new HashMap<String,Object>();
        reslut.put("reslutCode", "1");
        reslut.put("reslutMessage", "保存成功!");
        return reslut;
    }
    /**
    *修改对象
    */
    @RequestMapping(value = "/updateInsCanteenWeekMenuDetail", method = RequestMethod.POST)
    @ResponseBody
    public Map<String,Object> updateInsCanteenWeekMenuDetail(Integer id){
        InsCanteenWeekMenuDetail insCanteenWeekMenuDetail=new InsCanteenWeekMenuDetail();
        insCanteenWeekMenuDetail.setId(id);
        insCanteenWeekMenuDetailService.updateInsCanteenWeekMenuDetail(insCanteenWeekMenuDetail);
        Map<String,Object> reslut=new HashMap<String,Object>();
        reslut.put("reslutCode", "1");
        reslut.put("reslutMessage", "保存成功!");
        return reslut;
    }
    /**
    *删除对象
    */
    @RequestMapping(value = "/deleteInsCanteenWeekMenuDetail", method = RequestMethod.POST)
    @ResponseBody
    public Map<String,Object> deleteInsCanteenWeekMenuDetail(Integer id){
        InsCanteenWeekMenuDetail insCanteenWeekMenuDetail=new InsCanteenWeekMenuDetail();
        insCanteenWeekMenuDetail.setId(id);
        insCanteenWeekMenuDetailService.deleteInsCanteenWeekMenuDetail(insCanteenWeekMenuDetail);
        Map<String,Object> reslut=new HashMap<String,Object>();
        reslut.put("reslutCode", "1");
        reslut.put("reslutMessage", "保存成功!");
        return reslut;
    }
    /**
    *批量删除对象
    */
    @RequestMapping(value = "/deleteInsCanteenWeekMenuDetailBatch", method = RequestMethod.POST)
    @ResponseBody
    public Map<String,Object> deleteInsCanteenWeekMenuDetailBatch(String[] ids){
        insCanteenWeekMenuDetailService.deleteInsCanteenWeekMenuDetailBatch(Arrays.asList(ids));
        Map<String,Object> reslut=new HashMap<String,Object>();
        reslut.put("reslutCode", "1");
        reslut.put("reslutMessage", "保存成功!");
        return reslut;
    }
}
