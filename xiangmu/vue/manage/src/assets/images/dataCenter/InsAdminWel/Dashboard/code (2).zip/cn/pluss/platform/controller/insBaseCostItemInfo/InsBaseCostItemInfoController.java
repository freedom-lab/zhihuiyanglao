package cn.pluss.platform.controller.InsBaseCostItemInfo;

import cn.pluss.platform.base.BaseController;
import java.util.Map;
import java.util.List;
import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;
import cn.pluss.platform.util.StringUtil;
import javax.servlet.http.HttpServletRequest;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import cn.pluss.platform.model.entity.InsBaseCostItemInfo;
import cn.pluss.platform.insBaseCostItemInfo.InsBaseCostItemInfoService;

@Controller
@RequestMapping("insBaseCostItemInfo")
public class InsBaseCostItemInfoController  extends BaseController{

    private Integer PAGE_SIZE=12;

    @Autowired
    private InsBaseCostItemInfoService insBaseCostItemInfoService;

    /**
    *引导页
    * @return
    */
    @RequestMapping(value = "/index", method = RequestMethod.GET)
    public String index(HttpServletRequest request,Integer pageIndex) {
        if(pageIndex==null||pageIndex==0) {
        pageIndex=1;
        }
        request.setAttribute("pageIndex", pageIndex);
        return "insBaseCostItemInfo/insBaseCostItemInfoList";
    }

    /**
    *分页查询
    */
    @RequestMapping(value = "/queryInsBaseCostItemInfoByPage", method = RequestMethod.GET)
    @ResponseBody
    public  Map<String,Object> queryInsBaseCostItemInfoByPage(Integer page,Integer limit,Integer id) {

        if(page==null) {
        page=1;
        }
        Map<String,Object> map=new HashMap<String, Object>();
        map.put("pageSize",limit);
        map.put("offset",(page-1)*limit);
        map.put("id",  id);
        List<InsBaseCostItemInfo> insBaseCostItemInfoList=insBaseCostItemInfoService.queryPage(map);
        Integer count=insBaseCostItemInfoService.queryPageCount(map);
        Map<String,Object> reslut=new HashMap<String,Object>();
        reslut.put("code", 0);
        reslut.put("count", count);
        reslut.put("data",insBaseCostItemInfoList);
        return reslut;
    }
    /**
    *查询详情
    */
    @RequestMapping(value = "/queryInsBaseCostItemInfoDetails", method = RequestMethod.GET)
    public String queryInsBaseCostItemInfoDetails(HttpServletRequest request,Integer id,Integer pageIndex){

        if(id!=null&&id!=0) {
        InsBaseCostItemInfo insBaseCostItemInfo=new InsBaseCostItemInfo();
        insBaseCostItemInfo.setId(id);
        insBaseCostItemInfo=insBaseCostItemInfoService.queryInsBaseCostItemInfo(insBaseCostItemInfo);
        request.setAttribute("insBaseCostItemInfo", insBaseCostItemInfo);
        request.setAttribute("pageIndex", pageIndex);
        }
        return "insBaseCostItemInfo/insBaseCostItemInfoDetails";
    }
    /**
    *查询详情
    */
    @RequestMapping(value = "/queryInsBaseCostItemInfoBaseInfo", method = RequestMethod.GET)
    public String queryInsBaseCostItemInfoBaseInfo(HttpServletRequest request,Integer id,Integer pageIndex){

        if(id!=null&&id!=0) {
        InsBaseCostItemInfo insBaseCostItemInfo=new InsBaseCostItemInfo();
        insBaseCostItemInfo.setId(id);
        insBaseCostItemInfo=insBaseCostItemInfoService.queryInsBaseCostItemInfo(insBaseCostItemInfo);
        request.setAttribute("insBaseCostItemInfo", insBaseCostItemInfo);
        request.setAttribute("pageIndex", pageIndex);
        }
        return "insBaseCostItemInfo/insBaseCostItemInfoBaseInfo";
    }
    /**
    *查询详情
    */
    @RequestMapping(value = "/queryInsBaseCostItemInfoExtendsInfo", method = RequestMethod.GET)
    public String queryInsBaseCostItemInfoExtendsInfo(){

        return "insBaseCostItemInfo/insBaseCostItemInfodExtendsInfo";
    }
    /**
    *查询详情
    */
    @RequestMapping(value = "/queryInsBaseCostItemInfoFunctionsInfo", method = RequestMethod.GET)
    public String queryInsBaseCostItemInfoFunctionsInfo(){

        return "insBaseCostItemInfo/insBaseCostItemInfoFunctionsInfo";
    }
    /**
    *保存对象
    */
    @RequestMapping(value = "/saveInsBaseCostItemInfo", method = RequestMethod.POST)
    @ResponseBody
    public Map<String,Object> saveInsBaseCostItemInfo(InsBaseCostItemInfo insBaseCostItemInfo){

        if(insBaseCostItemInfo.getId()!=null&&insBaseCostItemInfo.getId()!=0){
            insBaseCostItemInfoService.updateInsBaseCostItemInfo(insBaseCostItemInfo);
        }else{
            insBaseCostItemInfoService.saveInsBaseCostItemInfo(insBaseCostItemInfo);
        }
        Map<String,Object> reslut=new HashMap<String,Object>();
        reslut.put("reslutCode", "1");
        reslut.put("reslutMessage", "保存成功!");
        return reslut;
    }
    /**
    *修改对象
    */
    @RequestMapping(value = "/updateInsBaseCostItemInfo", method = RequestMethod.POST)
    @ResponseBody
    public Map<String,Object> updateInsBaseCostItemInfo(Integer id){
        InsBaseCostItemInfo insBaseCostItemInfo=new InsBaseCostItemInfo();
        insBaseCostItemInfo.setId(id);
        insBaseCostItemInfoService.updateInsBaseCostItemInfo(insBaseCostItemInfo);
        Map<String,Object> reslut=new HashMap<String,Object>();
        reslut.put("reslutCode", "1");
        reslut.put("reslutMessage", "保存成功!");
        return reslut;
    }
    /**
    *删除对象
    */
    @RequestMapping(value = "/deleteInsBaseCostItemInfo", method = RequestMethod.POST)
    @ResponseBody
    public Map<String,Object> deleteInsBaseCostItemInfo(Integer id){
        InsBaseCostItemInfo insBaseCostItemInfo=new InsBaseCostItemInfo();
        insBaseCostItemInfo.setId(id);
        insBaseCostItemInfoService.deleteInsBaseCostItemInfo(insBaseCostItemInfo);
        Map<String,Object> reslut=new HashMap<String,Object>();
        reslut.put("reslutCode", "1");
        reslut.put("reslutMessage", "保存成功!");
        return reslut;
    }
    /**
    *批量删除对象
    */
    @RequestMapping(value = "/deleteInsBaseCostItemInfoBatch", method = RequestMethod.POST)
    @ResponseBody
    public Map<String,Object> deleteInsBaseCostItemInfoBatch(String[] ids){
        insBaseCostItemInfoService.deleteInsBaseCostItemInfoBatch(Arrays.asList(ids));
        Map<String,Object> reslut=new HashMap<String,Object>();
        reslut.put("reslutCode", "1");
        reslut.put("reslutMessage", "保存成功!");
        return reslut;
    }
}
