package cn.pluss.platform.controller.InsCanteenWeekMenu;

import cn.pluss.platform.base.BaseController;
import java.util.Map;
import java.util.List;
import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;
import cn.pluss.platform.util.StringUtil;
import javax.servlet.http.HttpServletRequest;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import cn.pluss.platform.model.entity.InsCanteenWeekMenu;
import cn.pluss.platform.insCanteenWeekMenu.InsCanteenWeekMenuService;

@Controller
@RequestMapping("insCanteenWeekMenu")
public class InsCanteenWeekMenuController  extends BaseController{

    private Integer PAGE_SIZE=12;

    @Autowired
    private InsCanteenWeekMenuService insCanteenWeekMenuService;

    /**
    *引导页
    * @return
    */
    @RequestMapping(value = "/index", method = RequestMethod.GET)
    public String index(HttpServletRequest request,Integer pageIndex) {
        if(pageIndex==null||pageIndex==0) {
        pageIndex=1;
        }
        request.setAttribute("pageIndex", pageIndex);
        return "insCanteenWeekMenu/insCanteenWeekMenuList";
    }

    /**
    *分页查询
    */
    @RequestMapping(value = "/queryInsCanteenWeekMenuByPage", method = RequestMethod.GET)
    @ResponseBody
    public  Map<String,Object> queryInsCanteenWeekMenuByPage(Integer page,Integer limit,Integer id) {

        if(page==null) {
        page=1;
        }
        Map<String,Object> map=new HashMap<String, Object>();
        map.put("pageSize",limit);
        map.put("offset",(page-1)*limit);
        map.put("id",  id);
        List<InsCanteenWeekMenu> insCanteenWeekMenuList=insCanteenWeekMenuService.queryPage(map);
        Integer count=insCanteenWeekMenuService.queryPageCount(map);
        Map<String,Object> reslut=new HashMap<String,Object>();
        reslut.put("code", 0);
        reslut.put("count", count);
        reslut.put("data",insCanteenWeekMenuList);
        return reslut;
    }
    /**
    *查询详情
    */
    @RequestMapping(value = "/queryInsCanteenWeekMenuDetails", method = RequestMethod.GET)
    public String queryInsCanteenWeekMenuDetails(HttpServletRequest request,Integer id,Integer pageIndex){

        if(id!=null&&id!=0) {
        InsCanteenWeekMenu insCanteenWeekMenu=new InsCanteenWeekMenu();
        insCanteenWeekMenu.setId(id);
        insCanteenWeekMenu=insCanteenWeekMenuService.queryInsCanteenWeekMenu(insCanteenWeekMenu);
        request.setAttribute("insCanteenWeekMenu", insCanteenWeekMenu);
        request.setAttribute("pageIndex", pageIndex);
        }
        return "insCanteenWeekMenu/insCanteenWeekMenuDetails";
    }
    /**
    *查询详情
    */
    @RequestMapping(value = "/queryInsCanteenWeekMenuBaseInfo", method = RequestMethod.GET)
    public String queryInsCanteenWeekMenuBaseInfo(HttpServletRequest request,Integer id,Integer pageIndex){

        if(id!=null&&id!=0) {
        InsCanteenWeekMenu insCanteenWeekMenu=new InsCanteenWeekMenu();
        insCanteenWeekMenu.setId(id);
        insCanteenWeekMenu=insCanteenWeekMenuService.queryInsCanteenWeekMenu(insCanteenWeekMenu);
        request.setAttribute("insCanteenWeekMenu", insCanteenWeekMenu);
        request.setAttribute("pageIndex", pageIndex);
        }
        return "insCanteenWeekMenu/insCanteenWeekMenuBaseInfo";
    }
    /**
    *查询详情
    */
    @RequestMapping(value = "/queryInsCanteenWeekMenuExtendsInfo", method = RequestMethod.GET)
    public String queryInsCanteenWeekMenuExtendsInfo(){

        return "insCanteenWeekMenu/insCanteenWeekMenudExtendsInfo";
    }
    /**
    *查询详情
    */
    @RequestMapping(value = "/queryInsCanteenWeekMenuFunctionsInfo", method = RequestMethod.GET)
    public String queryInsCanteenWeekMenuFunctionsInfo(){

        return "insCanteenWeekMenu/insCanteenWeekMenuFunctionsInfo";
    }
    /**
    *保存对象
    */
    @RequestMapping(value = "/saveInsCanteenWeekMenu", method = RequestMethod.POST)
    @ResponseBody
    public Map<String,Object> saveInsCanteenWeekMenu(InsCanteenWeekMenu insCanteenWeekMenu){

        if(insCanteenWeekMenu.getId()!=null&&insCanteenWeekMenu.getId()!=0){
            insCanteenWeekMenuService.updateInsCanteenWeekMenu(insCanteenWeekMenu);
        }else{
            insCanteenWeekMenuService.saveInsCanteenWeekMenu(insCanteenWeekMenu);
        }
        Map<String,Object> reslut=new HashMap<String,Object>();
        reslut.put("reslutCode", "1");
        reslut.put("reslutMessage", "保存成功!");
        return reslut;
    }
    /**
    *修改对象
    */
    @RequestMapping(value = "/updateInsCanteenWeekMenu", method = RequestMethod.POST)
    @ResponseBody
    public Map<String,Object> updateInsCanteenWeekMenu(Integer id){
        InsCanteenWeekMenu insCanteenWeekMenu=new InsCanteenWeekMenu();
        insCanteenWeekMenu.setId(id);
        insCanteenWeekMenuService.updateInsCanteenWeekMenu(insCanteenWeekMenu);
        Map<String,Object> reslut=new HashMap<String,Object>();
        reslut.put("reslutCode", "1");
        reslut.put("reslutMessage", "保存成功!");
        return reslut;
    }
    /**
    *删除对象
    */
    @RequestMapping(value = "/deleteInsCanteenWeekMenu", method = RequestMethod.POST)
    @ResponseBody
    public Map<String,Object> deleteInsCanteenWeekMenu(Integer id){
        InsCanteenWeekMenu insCanteenWeekMenu=new InsCanteenWeekMenu();
        insCanteenWeekMenu.setId(id);
        insCanteenWeekMenuService.deleteInsCanteenWeekMenu(insCanteenWeekMenu);
        Map<String,Object> reslut=new HashMap<String,Object>();
        reslut.put("reslutCode", "1");
        reslut.put("reslutMessage", "保存成功!");
        return reslut;
    }
    /**
    *批量删除对象
    */
    @RequestMapping(value = "/deleteInsCanteenWeekMenuBatch", method = RequestMethod.POST)
    @ResponseBody
    public Map<String,Object> deleteInsCanteenWeekMenuBatch(String[] ids){
        insCanteenWeekMenuService.deleteInsCanteenWeekMenuBatch(Arrays.asList(ids));
        Map<String,Object> reslut=new HashMap<String,Object>();
        reslut.put("reslutCode", "1");
        reslut.put("reslutMessage", "保存成功!");
        return reslut;
    }
}
