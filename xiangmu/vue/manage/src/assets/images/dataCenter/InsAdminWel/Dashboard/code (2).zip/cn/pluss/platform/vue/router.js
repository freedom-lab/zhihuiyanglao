
    const InsBaseCostInfo = () => import('../views/insBaseCostInfo/InsBaseCostInfo.vue')
    const InsBaseCostItemInfo = () => import('../views/insBaseCostItemInfo/InsBaseCostItemInfo.vue')

    { path: '/insBaseCostInfo', component: InsBaseCostInfo },
    { path: '/insBaseCostItemInfo', component: InsBaseCostItemInfo },





